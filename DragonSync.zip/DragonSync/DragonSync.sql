
use DragonSync;
create table spells(
spell_id int unsigned primary key not null auto_increment,
name varchar(80) not null,
description text not null,
school varchar(20) not null,
duration varchar (30) not null,
concentration bit not null,
spellRange varchar(30) not null,
vocalComponent bit not null,
somaticComponent bit not null,
materialComponents bit not null,
materialDescription text,
level tinyint unsigned not null,
classes text not null
);
create table charSpells(
spell_id int unsigned not null,
charSheet_id int unsigned not null,
foreign key (spell_id) references spells(spell_id),
foreign key (charSheet_id) references character_sheet(char_id)
);
create table class(
class_id int unsigned primary key not null auto_increment,
images mediumblob,
name varchar(80) not null,
lore mediumtext not null,
features mediumtext  not null,
addProficiencies tinytext not null
);
create table subclass(
subclass_id int unsigned primary key not null auto_increment,
images mediumblob,
name varchar(80) not null,
lore mediumtext not null,
features mediumtext  not null,
addProficiencies tinytext not null,
class_id int unsigned not null,
foreign key subclass(class_id) references class(class_id)
);
create table charClass(
class_id int unsigned not null,
charSheet_id int unsigned not null,
level int unsigned not null,
Cantrip tinyint unsigned not null,
spellSlot1 tinyint unsigned not null,
spellSlot2 tinyint unsigned not null,
spellSlot3 tinyint unsigned not null,
spellSlot4 tinyint unsigned not null,
spellSlot5 tinyint unsigned not null,
spellSlot6 tinyint unsigned not null,
spellSlot7 tinyint unsigned not null,
spellSlot8 tinyint unsigned not null,
spellSlot9 tinyint unsigned not null,
foreign key (class_id) references class(class_id),
foreign key (charSheet_id) references character_sheet(char_id)
);
create table charSubclass(
class_id int unsigned not null,
subclass_id int unsigned not null,
charSheet_id int unsigned not null,
level int unsigned not null,
Cantrip tinyint unsigned not null,
spellSlot1 tinyint unsigned not null,
spellSlot2 tinyint unsigned not null,
spellSlot3 tinyint unsigned not null,
spellSlot4 tinyint unsigned not null,
spellSlot5 tinyint unsigned not null,
spellSlot6 tinyint unsigned not null,
spellSlot7 tinyint unsigned not null,
spellSlot8 tinyint unsigned not null,
spellSlot9 tinyint unsigned not null,
foreign key (class_id) references subclass(class_id),
foreign key (subclass_id) references subclass(subclass_id),
foreign key (charSheet_id) references character_sheet(char_id)
);
create table race(
race_id int unsigned primary key not null auto_increment,
images blob,
name varchar(80) not null,
lore mediumtext  not null,
traits mediumtext not null,
speed tinytext not null,
AttributeIncrease tinytext not null
);
create table charRace(
race_id int unsigned not null,
charSheet_id int unsigned not null,
foreign key (race_id) references race(race_id),
foreign key (charSheet_id) references character_sheet(char_id)
);
create table subrace(
subrace_id int unsigned primary key not null auto_increment,
images blob,
name varchar(80) not null,
lore mediumtext  not null,
traits mediumtext not null,
speed tinytext not null,
AttributeIncrease tinytext not null,
race_id int unsigned not null,
foreign key subrace(race_id) references race(race_id)
);
create table charSubrace(
race_id int unsigned not null,
subrace_id int unsigned not null,
charSheet_id int unsigned not null,
foreign key (race_id) references subrace(race_id),
foreign key (subrace_id) references subrace(subrace_id),
foreign key (charSheet_id) references character_sheet(char_id)
);
create table item(
item_id int unsigned primary key not null auto_increment,
images blob,
name varchar(80) not null,
description text not null,
rarity varchar(80) not null,
type_1 varchar(80) not null,
type_2 varchar(80),
type_3 varchar(80),
gear_type varchar(300),
value int
);
create table charItems(
item_id int unsigned not null,
charSheet_id int unsigned not null,
foreign key (item_id) references item(item_id),
foreign key (charSheet_id) references character_sheet(char_id)
);
create table feats(
feat_id int unsigned primary key not null auto_increment,
name varchar(120) not null,
description mediumtext not null,
pre_requisitesBool bit not null,
pre_requisites tinytext
);
create table charFeats(
feat_id int unsigned not null,
charSheet_id int unsigned not null,
foreign key (feat_id) references feats(feat_id),
foreign key (charSheet_id) references character_sheet(char_id)
);
create table background(
background_id int unsigned primary key not null auto_increment,
name varchar(120) not null,
feature text not null,
lore mediumtext not null
);
create table charBackground(
background_id int unsigned not null,
charSheet_id int unsigned not null,
foreign key (background_id) references background(background_id),
foreign key (charSheet_id) references character_sheet(char_id)
);
create table character_sheet(
char_id int unsigned primary key not null auto_increment,
images mediumblob,
name varchar(120) not null,
str int not null,
dex int not null,
wis int not null,
charisma int not null,
Intelligence int not null,
con int not null,
skillProficiencies varchar(200) not null,
skillExpertises varchar(200),
tollProficiencies varchar(300),
tollExpertises varchar(300),
weaponProficiencies varchar(200) not null,
armorProficiencies varchar(200) not null,
max_hp int unsigned not null,
hit_dice varchar(45) not null,
current_hit_dice varchar(45) not null,
temp_hp int unsigned not null,
AC tinyint unsigned not null,
backstory mediumtext,
alignment char(2),
personality_traits mediumtext
);