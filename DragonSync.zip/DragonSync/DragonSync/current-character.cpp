#include "charactertemplate.h"
#include "charactertemplates.h"
#include "iostream"
#include "string"

using namespace charactermodel;

TemplateCharacter* currentCharacter = new TemplateCharacter; // Gotta remember to delete it

// From now on, it will need normal functionalities based on how it will work

