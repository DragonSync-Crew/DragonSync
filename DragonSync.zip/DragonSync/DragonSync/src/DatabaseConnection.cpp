#include "DatabaseConnection.h"

DatabaseConnection::DatabaseConnection()
{
    //ctor
}

DatabaseConnection::~DatabaseConnection()
{
    //dtor
}
