#include "charactertemplates.h"
#include "iostream"
#include "string"

using namespace std;

    // Pretty screwed up, if someone knows how to make it smaller and consume less resources, please notify me

    class ModifierClass{ // Another Franken-code, sorry
        public:
    int modifier (int stat){
        int resultantmodifier = 0;
        switch (stat){
        case 1:
            resultantmodifier = -5;
            break;

        case 2:
        case 3:
            resultantmodifier = -4;
            break;

        case 4:
        case 5:
            resultantmodifier = -3;
            break;

        case 6:
        case 7:
            resultantmodifier = -2;
            break;

        case 8:
        case 9:
            resultantmodifier = -1;
            break;

        case 10:
        case 11:
            resultantmodifier = 0;
            break;

        case 12:
        case 13:
            resultantmodifier = 1;
            break;

        case 14:
        case 15:
            resultantmodifier = 2;
            break;

        case 16:
        case 17:
            resultantmodifier = 3;
            break;

        case 18:
        case 19:
            resultantmodifier = 4;
            break;

        case 20:
        case 21:
            resultantmodifier = 5;
            break;

        case 22:
        case 23:
            resultantmodifier = 6;
            break;

        case 24:
        case 25:
            resultantmodifier = 7;
            break;

        case 26:
        case 27:
            resultantmodifier = 8;
            break;

        case 28:
        case 29:
            resultantmodifier = 9;
            break;

        case 30:
            resultantmodifier = 10;
            break;

        default:
            resultantmodifier = 0;
            break;}

        return resultantmodifier;}

    };

    class TemplateCharacter: public ModifierClass { // A little repetitive, but I think this will do, just don't know if changes will be stable
                public:
                // Regular stats
                int characterstr = 10; // Strength value
                int characterdex = 10; // Dexterity value
                int charactercon = 10; // Constitution value
                int characterint = 10; // Intelligence value
                int characterwis = 10; // Wisdom value
                int charactercha = 10; // Charisma value (Please don't call it something like "charchar" or "charcha")

                // Modifiers, also help me I cannot write small code

                int characterstrmod = modifier(characterstr); // Strength modifier
                int characterdexmod = modifier(characterdex); // Dexterity modifier
                int characterconmod = modifier(charactercon); // Constitution modifier
                int characterintmod = modifier(characterint); // Intelligence modifier
                int characterwismod = modifier(characterwis); // Wisdom modifier
                int characterchamod = modifier(charactercha); // Charisma modifier

                // Other values
                int characterac = 10 + characterdexmod; // Armor Class, standard value is 10 + Dexterity modifier

                // Proficiency Bonus is going to be written by the user, albeit the default +2 will be already the standard value
                int proficencybonus = 2;

                // Without proficiency for now, the bonus will be summed on the individual sheet, not the model
                int characterstrsavemod = characterstrmod; // Strength save modifier
                int characterdexsavemod = characterdexmod; // Dexterity save modifier
                int characterconsavemod = characterconmod; // Constitution save modifier
                int characterintsavemod = characterintmod; // Intelligence save modifier
                int characterwissavemod = characterwismod; // Wisdom save modifier
                int characterchasavemod = characterchamod; // Charisma save modifier

                // Other values
                int initiative = characterdexmod; // Base value
                int speed = 30; // In feet - Needs to be changed for some characters


                struct weaponsandarmorproficiency { // Will not have ALL proficiencies for the sake of being upgraded
                    bool martialweaponsproficient = false; // All values will be by default false
                    bool simpleweaponsproficient = false;
                    bool simplearmorproficiency = false;
                    bool mediumarmorproficiency = false;
                    bool heavyarmorproficiency = false;
                    bool shieldproficiency = false;
                };

                struct skillsproficiency { // Will store booleans, by the way, sorry for the gigantic value setting and names
                    bool acrobaticsproficiency, animalhandlingproficiency, arcanaproficiency, athleticsproficiency, deceptionproficiency, historyproficiency, insightproficiency, intimidationproficiency,
                    investigationproficiency, medicineproficiency, natureproficiency, perceptionproficiency, performanceproficiency, persuasionproficiency,
                    religionproficiency, sleightofhandproficiency, stealthproficiency, survivalproficiency = false;
                    /* Passive perception is going to be on the database part, and for calculating bonus it will be
                    ATRIBUTE_MOD + (proficiency bonus * int(SKILLproficiency)), the expertise would fir in here very well, but
                    it is not going to be used to pass the data to the DB - Same for HP, hit dice and others
                    */
                };
            };

    charactertemplates::~charactertemplates()
    {
        //dtor
    }
