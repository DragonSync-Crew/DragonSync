#ifndef DATABASECONNECTION_H
#define DATABASECONNECTION_H

//The guide for the MySQL C++ Connector told me to include these:
#include "mysql_connection.h" // Connector itself, I guess, perhaps I only need this one, but I dunno
#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>

using namespace sql::mysql; // There is probably a better way than doing this, but I am a noob, sorry

class DatabaseConnection
{
    public:
        DatabaseConnection();
        virtual ~DatabaseConnection();

    protected:
        void attemptConnection(){ // This calling probably is against the regular calling convention or something, sorry again

          try{
            sql::Driver *driver;
            sql::Connection *connection;
            sql::Statement *statement;
            sql::ResultSet *resultSet;

            // Warning, screwed up connection below
            driver = get_driver_instance();
            connection = driver->connect("tcp://127.0.0.1:3306", "root", "");
            connection->setSchema("DragonSync");

            statement = con->createStatement();
            resultSet = statement->executeQuery("SELECT 'Hello World!' AS _message");
            //Better not give any user root access, at least not on the long run
          } catch (sql::SQLException &e){
            cout << "# ERR: SQLException in " << __FILE__;
            cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
            cout << "# ERR: " << e.what();
            cout << " (MySQL error code: " << e.getErrorCode();
            cout << ", SQLState: " << e.getSQLState() << " )" << endl;
          }
        }

    private:
};

#endif // DATABASECONNECTION_H
